#include <stdio.h>
#include <conio.h>
#include <iostream>

using namespace std;

/*exemplo para utilizar:
Tam tanque: 100L
Consumo do carro: 12km/L
Distancia percorrida: 1500km
Valor do litro: R$7,50
*/

int main(){
    float consumo_Carro, distancia, preco_Combustivel, total_Combustivel; 
    int qnts_Litros, qtd_Abastecimento, tam_Tanque;

    system("CLS");

    cout << "Qual o tamanho do tanque? ";
    cin >> tam_Tanque;

    cout << "Qual o consumo do carro? ";
    cin >> consumo_Carro;

    cout << "Qual a distancia que vai ser percorrida? ";
    cin >> distancia;

    cout << "Qual o preco do combustivel? ";
    cin >> preco_Combustivel;

    system("CLS");

    qnts_Litros = distancia/consumo_Carro;

    if (qnts_Litros%tam_Tanque == 0){
        qtd_Abastecimento = qnts_Litros/tam_Tanque;
    }
    else{
        qtd_Abastecimento = (qnts_Litros/tam_Tanque)+1;
    }
    
    total_Combustivel = (tam_Tanque*qtd_Abastecimento)*preco_Combustivel;

    cout << "Serao necessarios " << qnts_Litros << "L para a viagem" << endl;
    cout << "Sera necessario abastecer " << qtd_Abastecimento << " vezes" << endl;
    printf("Voce ira gastar R$%.2f", total_Combustivel);
    
    getch();
}